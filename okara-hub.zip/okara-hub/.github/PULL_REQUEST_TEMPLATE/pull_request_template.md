## Summary

<!-- What does this PR do? One or two sentences. -->

## Type of change

- [ ] Bug fix
- [ ] New feature / provider
- [ ] Refactor / code quality
- [ ] Docs / config only

## Related issue

Closes #<!-- issue number -->

## Testing

<!-- How did you test this? -->

- [ ] Tested in `npm run dev`
- [ ] No new ESLint warnings (`npx eslint src/`)
- [ ] Manually verified the changed behaviour

## Checklist

- [ ] Commits follow the `type: description` format
- [ ] `README.md` updated if user-facing behaviour changed
- [ ] `CHANGELOG.md` entry added under `[Unreleased]`
