/**
 * electron/updater.js
 * 
 * Updates for Neural Dock are delivered directly by Claude.
 * When you get a new neural-dock.tar.gz, just run:
 *
 *   ./update.sh ~/Downloads/neural-dock.tar.gz
 *
 * That's it — it rebuilds and reinstalls everything automatically.
 * No internet check, no GitHub, no server needed.
 */

const { app } = require('electron');
const CURRENT_VERSION = app.getVersion();

function init() {
  // No-op: updates are applied via update.sh
}

function setWindow() {}
async function checkForUpdate() {}
async function downloadAndInstall() {}

module.exports = { init, setWindow, checkForUpdate, downloadAndInstall, CURRENT_VERSION };
